package com.example.nearpointsofinterest.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.nearpointsofinterest.R;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;



public class StorkFragment extends Fragment {

    //private WebView mWebView;
    //private String mFormUrl = "https://stork.ee.auth.gr/";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stork, container, false);
        //mWebView = (WebView) view.findViewById(R.id.webview);
        //mWebView.getSettings().setJavaScriptEnabled(true);
        //mWebView.setWebViewClient(new WebViewClient());
        //mWebView.loadUrl(mFormUrl);

        //mWebView.loadUrl("stork.ee.auth.gr");
        WebView webView = (WebView) view.findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("stork.ee.auth.gr");

        return view;
    }
}

