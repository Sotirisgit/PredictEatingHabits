package com.example.nearpointsofinterest.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.nearpointsofinterest.Model.Restaurant;
import com.example.nearpointsofinterest.R;

import com.google.android.libraries.places.api.model.Place;


import java.util.List;
import android.content.Context;



import com.example.nearpointsofinterest.Model.PlaceItem;


public class PlaceAdapter extends RecyclerView.Adapter<PlaceAdapter.PlaceViewHolder> {

    private List<PlaceItem> placeList;

    public PlaceAdapter(List<PlaceItem> placeList) {
        this.placeList = placeList;
    }


    @NonNull
    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_item, parent, false);
        return new PlaceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, int position) {
        PlaceItem place = placeList.get(position);
        holder.nameTextView.setText(place.getName());
        holder.typeTextView.setText(place.getType());
    }

    @Override
    public int getItemCount() {
        return placeList.size();
    }

    public static class PlaceViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView typeTextView;

        public PlaceViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.name_text_view);
            typeTextView = itemView.findViewById(R.id.type_text_view);
        }
    }
}
