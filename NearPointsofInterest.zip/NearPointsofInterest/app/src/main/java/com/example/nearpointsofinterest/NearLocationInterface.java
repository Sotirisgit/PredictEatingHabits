package com.example.nearpointsofinterest;

public interface NearLocationInterface {

    void onSaveClick(GooglePlaceModel googlePlaceModel);

    void onDirectionClick(GooglePlaceModel googlePlaceModel);
}

