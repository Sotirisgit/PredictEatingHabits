package com.example.nearpointsofinterest;

public interface SavedLocationInterface {

    void onLocationClick(SavedPlaceModel savedPlaceModel);
}
