package com.example.nearpointsofinterest.Model;

public class DataModel {

    String name;
    String types;
    double rating;
    String address;


    public DataModel(String name, String types, double rating, String address ) {
        this.name=name;
        this.types=types;
        this.rating=rating;
        this.address=address;


    }

    public String getName() {
        return name;
    }

    public String getType() {
        return types;
    }

    public double getRating() {
        return rating;
    }

    public String getAddress() {
        return address;
    }

}