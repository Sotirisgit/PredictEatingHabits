package com.example.nearpointsofinterest.Fragments;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import com.example.nearpointsofinterest.R;
import com.example.nearpointsofinterest.Restaurant;

import android.widget.TextView;
import android.util.Log;





public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.RestaurantViewHolder> {

    private List<Restaurant> restaurantList;

    public RestaurantAdapter(List<Restaurant> restaurantList) {
        this.restaurantList = restaurantList;
    }

    @Override
    public RestaurantViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_restaurant, parent, false);
        return new RestaurantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RestaurantViewHolder holder, int position) {
        Restaurant restaurant = restaurantList.get(position);
        holder.nameTextView.setText(restaurant.getName());


       // Log.d("RestaurantAdapter", "onBindViewHolder called with position: " + position + " and restaurant name: " + restaurant.getName());


        Log.d("RestaurantAdapter", "onBindViewHolder called with position: " + ", restaurant name: " + restaurant.getName() +
                ", and restaurant type: " + restaurant.getType());


    }

    @Override
    public int getItemCount() {
        return restaurantList.size();
    }

    public static class RestaurantViewHolder extends RecyclerView.ViewHolder {

        public TextView nameTextView;
        public TextView addressTextView;
        public TextView ratingTextView;

        public TextView typesTextView;

        public RestaurantViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            addressTextView = itemView.findViewById(R.id.addressTextView);
            ratingTextView = itemView.findViewById(R.id.ratingTextView);
            typesTextView = itemView.findViewById(R.id.typesTextView);
        }
    }
}

