package com.example.nearpointsofinterest.Fragments;


import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.nearpointsofinterest.R;

public class RestaurantViewHolder extends RecyclerView.ViewHolder {
    private TextView tvRestaurantName;

    public RestaurantViewHolder(@NonNull View itemView) {
        super(itemView);
        tvRestaurantName = itemView.findViewById(R.id.name_text_view);
    }

    public void bindData(String restaurantName) {
        tvRestaurantName.setText(restaurantName);
    }
}
