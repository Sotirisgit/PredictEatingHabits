package com.example.nearpointsofinterest;



public class Restaurant {
    public String name;
    public String type;
    public double rating;
    public String address;
    //private String[] type;


    public Restaurant(String name, String type, double rating, String vicinity) {
        this.name = name;
        this.type = type;
        this.rating = rating;
        this.address = vicinity;
    }

    public String getName() {return name;}

    public String getType() {return type; }

    public double getRating() {return rating; }
    public String getAddress() {return address; }

}







/*
public class Restaurant {
    // Define the properties of the Restaurant class here
    private String name;
    private String address;

    // Define any constructors, getters, and setters for the class here
    public Restaurant(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    // Override the toString() method for debugging purposes
    @Override
    public String toString() {
        return "Restaurant{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
*/