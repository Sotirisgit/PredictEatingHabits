package com.example.nearpointsofinterest.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.nearpointsofinterest.Restaurant;
import com.example.nearpointsofinterest.R;

import java.util.ArrayList;


public class NearbyAdapter extends RecyclerView.Adapter<NearbyAdapter.PlaceViewHolder> {

    private ArrayList<Restaurant> restaurantList;

    public NearbyAdapter(ArrayList<Restaurant> restaurantList) {
        this.restaurantList = restaurantList;
    }


    @NonNull
    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_item, parent, false);
        return new PlaceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, int position) {
//        onBindViewHolder(holder, position, getItem(position));
        Restaurant restaurant = restaurantList.get(position);
//        holder.txtPlaceName.setText(restaurant.getName());
//        holder.txtPlaceAddress.setText(restaurant.getAddress());
    }

    @Override
    public int getItemCount() {
        return restaurantList.size();
    }

    public static class PlaceViewHolder extends RecyclerView.ViewHolder {
        TextView txtPlaceName;
        TextView txtPlaceAddress;

        public PlaceViewHolder(@NonNull View itemView) {
            super(itemView);
            txtPlaceName = itemView.findViewById(R.id.txtPlaceName);
            txtPlaceAddress = itemView.findViewById(R.id.txtPlaceAddress);
        }
    }
}
