package com.example.nearpointsofinterest.Fragments;



import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;






public class GetNearbyPlacesData {
    private static final String TAG = "GetNearbyPlacesData";

    public List<HashMap<String, String>> getNearbyPlacesData(String url) {
        List<HashMap<String, String>> nearbyPlacesList = null;
        String json = null;
        try {
            json = getJson(url);
        } catch (Exception e) {
            Log.e(TAG, "Error getting JSON data.", e);
        }
        if (json != null) {
            try {
                JSONObject jsonObject = new JSONObject(json);
                nearbyPlacesList = parse(jsonObject);
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing JSON data.", e);
            }
        }
        return nearbyPlacesList;
    }

    private List<HashMap<String, String>> parse(JSONObject jsonObject) {
        List<HashMap<String, String>> nearbyPlacesList = new ArrayList<>();
        JSONArray results = null;
        try {
            results = jsonObject.getJSONArray("results");
            for (int i = 0; i < results.length(); i++) {
                JSONObject place = results.getJSONObject(i);
                HashMap<String, String> nearbyPlace = new HashMap<>();
                nearbyPlace.put("name", place.getString("name"));
                nearbyPlace.put("vicinity", place.getString("vicinity"));
                nearbyPlacesList.add(nearbyPlace);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing JSON data.", e);
        }
        return nearbyPlacesList;
    }

    private String getJson(String url) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }
}
