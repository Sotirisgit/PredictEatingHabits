package com.example.nearpointsofinterest.Fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.nearpointsofinterest.Adapter.CustomAdapter;
import com.example.nearpointsofinterest.Model.DataModel;
import com.example.nearpointsofinterest.NearLocationInterface;
import com.example.nearpointsofinterest.R;
import com.example.nearpointsofinterest.Utility.LoadingDialog;
import com.example.nearpointsofinterest.databinding.FragmentNearbyRestaurantsBinding;
import java.util.ArrayList;
import static android.content.Context.MODE_PRIVATE;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class NearbyRestaurantsFragment extends Fragment{

    ArrayList<DataModel> dataModels;
    ListView listView;
    private static CustomAdapter adapter;
    SharedPreferences sharedPreferences;
    private static final String TAG = "myApp";
    private LoadingDialog loadingDialog;
    private FragmentNearbyRestaurantsBinding binding;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_nearby_restaurants, container, false);

        binding = FragmentNearbyRestaurantsBinding.inflate(inflater, container, false);
        sharedPreferences = requireActivity().getSharedPreferences("MySharedPref",MODE_PRIVATE);

        // Log a message to confirm that the RecyclerView and adapter were properly set up
        Log.d(TAG, "RecyclerView and adapter set up successfully.");

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        loadingDialog = new LoadingDialog(requireActivity());

        try {
            deserializeJSON();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "NearbyRestaurants Destroyed");
    }

    private void deserializeJSON() throws JSONException {
        loadingDialog.startLoading();

        dataModels= new ArrayList<>();
        listView=(ListView)binding.list;

        try {
            String restaurants = sharedPreferences.getString("restaurants", "");
            JSONObject obj = new JSONObject(restaurants);
            JSONArray jsonArray = obj.optJSONArray("results");
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject restaurant = jsonArray.getJSONObject(i);
                    Log.d(TAG, restaurant.toString());

                    String name = restaurant.getString("name");
                    JSONArray types = restaurant.getJSONArray("types");
                    String type = types.get(0).toString();
                    double rating = restaurant.getDouble("rating");
                    String vicinity = restaurant.getString("vicinity");
                    dataModels.add(new DataModel(name, type, rating, vicinity));
                }
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        adapter= new CustomAdapter(dataModels,getActivity());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                DataModel dataModel= dataModels.get(position);

                Snackbar.make(view, dataModel.getName()+"\n"+dataModel.getType()+" Rating: "+dataModel.getRating(), Snackbar.LENGTH_LONG)
                        .setAction("No action", null).show();
            }
        });

        loadingDialog.stopLoading();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

}

