package com.example.nearpointsofinterest.Fragments;

import com.example.nearpointsofinterest.GooglePlaceModel;

public interface HomeFragmentIF {
    void onSaveClick(GooglePlaceModel googlePlaceModel);

    void onDirectionClick(GooglePlaceModel googlePlaceModel);
}
